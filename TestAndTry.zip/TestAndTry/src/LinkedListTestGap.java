
public class LinkedListTestGap {

	static NodeGap head=null;
	
	static void insert(int value) {
		
		NodeGap node = null;
		NodeGap ptr = null;
		
		if(head == null) {
			node = new NodeGap(value);
			head = node;
		} else {
			
			ptr = head;
			
			while(ptr.next != null) {
				ptr = ptr.next;
			}
			
			node = new NodeGap(value);
			ptr.next = node;
			//node.prev = ptr;
		}
	}
	
	static void print() {
		
		if(head == null) {
			System.out.println("No node in list");
		}
		
		NodeGap ptr = null;
		ptr = head;
		
		System.out.println("print");
		
		while(ptr.next != null) {
			
			System.out.print(ptr.data +"->");
			ptr = ptr.next;
		}
		
		System.out.println(ptr.data);
		
//		System.out.println("Backward print");
//		
//		while(ptr.prev !=null) {
//			System.out.print(ptr.data +"->");
//			ptr = ptr.prev;
//		}
//		System.out.println(ptr.data);
	}
	
	
	
	
	
	public static void main(String[] args) {
		
		//NodeGap node = new NodeGap(1);
		
		insert(1);
		insert(2);
		insert(3);
		print();
		reverseLinkedList();
		print();
	}

	private static void reverseLinkedList() {
		// TODO Auto-generated method stub
		NodeGap prev = null;
		NodeGap curr = head;
		
		// (head/curr)
		//       1	->	2	->	3
		while(curr !=null) {
			NodeGap nextTemp = curr.next; // hold next pointer of current node
			curr.next = prev; // set previous to the next of current, initially it is null
			prev = curr;	// now set prev to current node 
			curr = nextTemp;
		}
		
		head = prev;
		
	}
	
}


class NodeGap{
	
	int data;
	NodeGap next;
	//NodeGap prev;
	
	public NodeGap() {
		// TODO Auto-generated constructor stub
	}
	
	public NodeGap(int data) {
		// TODO Auto-generated constructor stub
		this.data = data;
		this.next = null;
		//this.prev = null;
	}
	
}

/**
*	 reverse a LL 
*	1 -> 2 -> 3
*	3 -> 2 -> 1
* 	
*/