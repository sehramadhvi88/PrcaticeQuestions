package com.learningtechjs;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TimeDifference {

	public static void main(String[] args) throws ParseException {
		
		System.out.println(calculateAverageSpeed("12:01","13:16",42.0));
		 
		
	}
	
	private static double calculateAverageSpeed(String time1,String time2, double miles) throws ParseException { 
	
		DecimalFormat crunchifyFormatter = new DecimalFormat("###,###");
		 
		SimpleDateFormat format = new SimpleDateFormat("HH:mm", Locale.ENGLISH);
		Date date = format.parse(time1);
		Date date2 = format.parse(time2);

		System.out.println("Time: " + date+ " "+date.getTime());
		System.out.println("Time: " + date2+ " "+date2.getTime());
		long diff = date2.getTime() - date.getTime();
		System.out.println("diff=="+diff); 
		int totalTime = (int)(diff/(60*60*1000));
		System.out.println("totalTime="+crunchifyFormatter.format(totalTime));

		return  (miles / totalTime);
		}
	    
	
}
	

