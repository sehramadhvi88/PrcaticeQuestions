/**
 *  what is strict mode ? 
 *  ECMAScript5
 * 
 */

"use strict";

(function() {
	console.log(“Hello, World!”);
	})();

