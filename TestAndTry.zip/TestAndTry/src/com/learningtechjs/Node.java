package com.learningtechjs;


public class Node {
	
	int data;
	Node next,prev;
	
	public Node(int data) {
		// TODO Auto-generated constructor stub
		this.data = data;
		next = prev = null;	
	}
}
