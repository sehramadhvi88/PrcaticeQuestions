package com.learningtechjs;

public class LinkedList {
	
	Node head;
	Node tail;
	
	public void insert(int data) {
		
		if(head == null) {
			head = new Node(data);
		}else {
			Node node = new Node(data);
			Node ptr = head;
			while(ptr.next != null) {
				ptr = ptr.next;
			}
			ptr.next=node;
			node.prev = ptr;
			tail = node;
		}
	}
	
	public void printList() {
		
		Node ptr = head;
		//forward
		System.out.println("Forward print");
		while(ptr != null) {
			System.out.print(ptr.data+"->");
			ptr=ptr.next;
		}
		
		System.out.println("null");
		
		Node prevPtr = tail;
		// backward print
		System.out.println("backward print");
		while(prevPtr != null) {
			System.out.print(prevPtr.data+"->");
			prevPtr=prevPtr.prev;
		}
		System.out.println("null");

	}
	
	public static void main(String[] args) {
		
		
		
		LinkedList list1 = new LinkedList();
		
		list1.insert(1);
		list1.insert(2);
		list1.insert(3);
		list1.insert(4);
		
		System.out.println("list after insertion ");
		list1.printList();
		
	}
}

/* 
 *  insertion operation :
 *  	1) at front 
 *  		only one pointer need to maintain , insert operation would be of O(1) 
 *  	2) at end
 *  		need to traverse complete list O(n) , second option we can maintain a tail pointer to insert at end
 * 
 * 			| ptr | info | ptr |
 * 			
 * 
 */
