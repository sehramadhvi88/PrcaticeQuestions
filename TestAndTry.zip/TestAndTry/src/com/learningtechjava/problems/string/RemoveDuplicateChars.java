package com.learningtechjava.problems.string;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class RemoveDuplicateChars {

	public static void main(String[] args) {
		
		String str = "geeksofgeeks";
		char ch = 'e';
		
		System.out.println(removeDuplicates(str));
		System.out.println(removeDuplicates1(str));
		System.out.println(removeDuplicates2(str));
		System.out.println(removeCharacter(str,ch));

	}

	private static String removeCharacter(String str, char ch) {
		// TODO Auto-generated method stub
		return str.chars(). // convert into IntStream
				filter(c -> c !=ch). // filter out 
				mapToObj(c -> String.valueOf((char)c)). // map int to stream of string
						collect(Collectors.joining());  // join
	}

	private static String removeDuplicates2(String str) {
		// TODO Auto-generated method stub
		return Arrays.asList(str.split("")).stream(). // stream of strings 
					distinct().collect(Collectors.joining());
	}

	private static String removeDuplicates1(String str) {
		// TODO Auto-generated method stub
		char[] chArray = str.toCharArray();
		StringBuilder sb = new StringBuilder();
		Set<Character> hset = new HashSet<>(); 
		
		for(char ch:chArray) {
			if(hset.add(ch)) {
				sb.append(ch);
			}
		}
		
		return sb.toString();
	}

	private static String removeDuplicates(String str) {
		// TODO Auto-generated method stub
	
		char[] chArray = str.toCharArray();
		StringBuilder sb = new StringBuilder();
		
		for(char ch:chArray) {
			if(sb.indexOf(String.valueOf(ch)) == -1) {
				sb.append(ch);
			}
		}
		
		return sb.toString();
		
	}
	
}
