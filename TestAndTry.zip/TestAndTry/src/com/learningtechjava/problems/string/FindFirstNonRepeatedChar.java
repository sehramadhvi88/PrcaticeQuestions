package com.learningtechjava.problems.string;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindFirstNonRepeatedChar {
	
	static char count[] = new char[256]; // ASCII system are 256	

	public static void main(String[] args) {
		
		String str="geeksforgeeks";
		System.out.println(firstNonRepeatedCharacter1(str));
		System.out.println(firstNonRepeatedCharacter2(str));
		System.out.println(firstNonRepeatedCharacter3(str));

	}

	private static String firstNonRepeatedCharacter3(String str) {
		// TODO Auto-generated method stub
		Map<Integer, Long> chs = str.codePoints() // return unicode
							.mapToObj(c -> c)
							.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()));
							// Function.identity() = c-> c
		System.out.println(chs); 
		
		int index = chs.entrySet().stream().filter(e -> e.getValue() == 1L).findFirst().map(Map.Entry::getKey)
						.orElse(Integer.valueOf(Character.MIN_VALUE));
		System.out.println(index); 
		return String.valueOf(Character.toChars(index));
	}

	private static int firstNonRepeatedCharacter1(String str) {
		// TODO Auto-generated method stub
		
		getCharCountArray(str);
		int index = -1;
		
		
		for(char c:str.toCharArray()) {
			if(count[c] == 1) {
				index = str.indexOf(c);
				break;
			}
		}
		return index;
	}

	private static void getCharCountArray(String str) {
		// TODO Auto-generated method stub
		for (char c : str.toCharArray()) {
			count[c]++;
		}
	}

	private static char firstNonRepeatedCharacter2(String str) {
		// TODO Auto-generated method stub
		
		Map<Character, Integer> chars = new LinkedHashMap<>();
		
		for(char ch: str.toCharArray()) {
			chars.compute(ch, (k,v) -> (v == null)? 1:++v);
		}
		// using compute instead of put 
		
		for(Entry<Character, Integer> entries:chars.entrySet()) {
			if(entries.getValue() == 1) {
				return entries.getKey();
			}
		}
		return Character.MIN_VALUE;
	}
}

/*
*  1. Single traversal 
*  2. iterate over string and count occurrence 
*  3. use map and return key with value 1 
*
*/