package com.learningtechjava.problems.string;

import java.util.Arrays;
import java.util.StringJoiner;
import java.util.stream.Collectors;

public class JoiningMultipleStrings {

	public static void main(String[] args) {
		
		/**
		 * 1 . use string builder append
		 * 2. use + operator 
		 * 3. use StringJoiner utility class ( from java 8)
		 * 4. use Collectors.joining() ( java 8 )
		 * 
		 */
		
		char delimiter = ' ';
		
		System.out.println(joinByDelimiter(delimiter,args));		
		System.out.println(joinByDelimiter2(delimiter,args));		

	}

	private static String joinByDelimiter2(char delimiter, String[] args) {
		// TODO Auto-generated method stub
		StringJoiner joiner = new StringJoiner(String.valueOf(delimiter));
		for(String arg:args) {
			joiner.add(arg);
		}
		
		return joiner.toString();
	}

	private static String joinByDelimiter(char delimiter, String[] args) {
		// TODO Auto-generated method stub
		 return Arrays.stream(args, 0, args.length).collect(Collectors.joining(String.valueOf(delimiter))); 
	}
	
}
