package com.learningtechjava.problems.string;

public class CheckRotatedStringPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

/*
 * 	Given a string check if it is a rotated palindrome 
 * 
 * example:
 * 
 * INPUT = "cbbcd" 
 * OUTPUT : TRUE
 * In the above example, the given string "cbbcd" is a rotation of a palindrom "bcdcb"
 * 
 * Input : CBAABCD 
 * Input : BAABCC
 * 
 * we have find all rotation : to check its a palindrome string 
 * 
 * solution : 
 * 
 * break the string in two parts s1 = [0 - i+1 ], s2 = [i+1- n-1+1] , then append s2 with s1 then 
 * check new string is palindrome or not
 * 
 * str = baabcc
 * 
 * s1 = b | s2 = aabcc
 * 
 * s2s1=aabccb ( not a plaindrome )
 * 
 * s1 = ba | s2 = abcc
 * 
 * s2s1 = abccba ( this is palindrome) 
 * 
 * time complexity : O(n^2) 
 * 
 * 
 */


