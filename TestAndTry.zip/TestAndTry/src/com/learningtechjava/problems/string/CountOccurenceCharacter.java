package com.learningtechjava.problems.string;

public class CountOccurenceCharacter {

	public static void main(String[] args) {
		
		
		String str ="hello";
		char ch = 'l';
		
		System.out.println(countOccurrencesOfACertainCharacter(str, ch));
		System.out.println(countOccurrencesOfACertainCharacter2(str, ch));

	}

	private static int countOccurrencesOfACertainCharacter2(String str, char ch) {
		// TODO Auto-generated method stub
		return (int) str.chars().filter(c -> c == ch).count();
	}

	private static int countOccurrencesOfACertainCharacter(String str, char ch) {
		// TODO Auto-generated method stub
		return str.length() - str.replace(String.valueOf(ch), "").length();
	}
	
}
