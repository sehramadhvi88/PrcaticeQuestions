package com.learningtechjava.problems.string;

import java.util.Arrays;

//Two strings that have the same characters, but that are in a different order, are anagrams.
public class CheckAnagram {

	public static void main(String[] args) {
		
		String str = "listen";
		String str2 = "silent";
		
		System.out.println(areAnagram(str , str2));
		System.out.println(areAnagram2(str , str2));
		
		

	}

	private static boolean areAnagram2(String str, String str2) {
		// TODO Auto-generated method stub
		int EXTENDED_ASCII_CODES = 256;
		int[] chCounts = new int[EXTENDED_ASCII_CODES];
		
		if(str.length() != str2.length()) {
			return false;
		}
		
		char[] arr1 = str.toCharArray();
		char[] arr2 = str2.toCharArray();
		
		for (int i = 0; i < arr1.length; i++) {
		    chCounts[arr1[i]]++;
		    chCounts[arr2[i]]--;
		  }
		
		for (int i = 0; i < chCounts.length; i++) {
		    if (chCounts[i] != 0) {
		      return false;
		    }
		  }
		
		return true;
	}

	private static boolean areAnagram(String str, String str2) {
		// TODO Auto-generated method stub
		
		if(str.length() != str2.length()) {
			return false;
		}
		
		char[] arr1 = str.toCharArray();
		char[] arr2 = str2.toCharArray();
		
		Arrays.sort(arr1);
		Arrays.sort(arr2);
		
		return String.valueOf(arr1).equals(String.valueOf(arr2));
		
		
	}
}


/**
*  Solution 
*  1. sort both string and compare
*  2. Use count array of 256 ASCII chars 
*
*
*/
