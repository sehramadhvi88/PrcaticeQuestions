package com.learningtechjava.problems.string;

import java.util.Scanner;

public class CheckLongestPalidromicSubstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
        String A=sc.next();
        /* Enter your code here. Print output to STDOUT. */
        char[] strArr=A.toCharArray();
        boolean flag = true;

        for(int i=0,j=strArr.length-1;i<strArr.length/2;i++,j--){
                if(!String.valueOf(strArr[i]).equals(String.valueOf(strArr[j]))) {
                	flag = false;
                }
        }
        
        System.out.println(flag);

	}

}
