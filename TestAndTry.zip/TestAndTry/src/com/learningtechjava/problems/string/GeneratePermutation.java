package com.learningtechjava.problems.string;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class GeneratePermutation {

	public static void main(String[] args) {
		
		String str = "ABC";
		
		permuteAndPrint(str);
		permuteAndReturnStream(str);

		System.out.println();
		
	}

	private static Stream<String> permuteAndReturnStream(String str) {
		// TODO Auto-generated method stub
		if(str.isEmpty())
		{
			return Stream.of("");
		}
		
		return IntStream.range(0, str.length())
					.parallel()
					.boxed()
					.flatMap(i -> permuteAndReturnStream(str.substring(0, i) + str.substring(i + 1))
					.map(c -> str.charAt(i) + c));
		
	}

	private static void permuteAndPrint(String str) {
		// TODO Auto-generated method stub
		if(str.isEmpty()) {
			return;
		}
		
		permuteAndPrint("",str);
	}

	private static void permuteAndPrint(String prefix, String str) {
		// TODO Auto-generated method stub
		
		int n = str.length();
		if(n == 0) {
			System.out.println(prefix + " ");
		} else {
			for(int i=0;i<n;i++) {
				permuteAndPrint(prefix+str.charAt(i), str.substring(i+1, n)+str.substring(0,i));
			
				/**
				 *  permuteAndPrint("","abc")
				 *  
				 *  for i-> 0 to n  , n = 3 [ 0,1,2]
				 *  
				 *  i = 0 
				 * 
				 * prefix+str.charAt(0)  = a
				 * str.substring(0+1, 3)+str.substring(0,0) = bc
				 * permuteAndPrint("a","bc") , n = 2
				 * 		|
				 * 		|
				 * 		V
				 * for i-> 0 to n  , n = 2 [ 0,1]
				 * 
				 * i = 0 
				 * prefix+str.charAt(0)  = a+b = ab
				 * str.substring(0+1, 2)+str.substring(0,0) = c
				 * permuteAndPrint("ab","c") , n = 1
				 * 		|
				 * 		|--->  for i-> 0 to n  , n = 1 [0]
				 * 			   prefix+str.charAt(0)  = ab+c = abc
				 * 			   str.substring(0+1, 1)+str.substring(0,0) = ""
				 * 			   permuteAndPrint("abc","") , n = 0 --> abc
				 * 
				 * 
				 * i = 1
				 * prefix+str.charAt(1)  = a+c = ac
				 * str.substring(1+1, 2)+str.substring(0,1) = b
				 * permuteAndPrint("ac","b") , n = 1
				 * 		|
				 * 		|--->  for i-> 0 to n  , n = 1 [0]
				 * 			   prefix+str.charAt(0)  = ac+b = acb
				 * 			   str.substring(0+1, 1)+str.substring(0,0) = ""
				 * 			   permuteAndPrint("acb","") , n = 0 --> acb
				 * 
				 * same for i = 1 and 2 on main loop 
				 *
				 */
				 /**
				  * 					abc
				  * 			 		|
				  * 	i=0	/	 	i=1	|			\i=2
				  * 	a, bc		  b, ca			c, ab
				  * 	 |				|			 |
				  * i=0	/ \ i=1	   i=0 / \ i=1	i=0 / \ i=1
				  * ab,c	ac,b 	bc,a  ba,c 	ca,b   cb,a
				  *  |		|		  |		|	  |		|
				  *  abc	acb		bca		bac  cab	cba
				  * 
				  */
			}
		}
		
		
	}
	
}
