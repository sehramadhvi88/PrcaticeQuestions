package com.learningtechjava.problems.string;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class CountDuplicateChars {
	
	public static void main(String[] args) {
		
		String str="geeksofgeeks";
		
		countDuplicateCharacters(str);
		countDuplicateCharacters1(str);
		System.out.println(countMaxOccurence(str));
		System.out.println(countMaxOccurence1(str));

	}
	
	private static char countMaxOccurence1(String str) {
		// TODO Auto-generated method stub
		return str.chars()
				.mapToObj(c -> (char)c)
				.collect(Collectors.groupingBy(c-> c,Collectors.counting()))
				.entrySet()
				.stream()
				.max(Map.Entry.comparingByValue())  //  terminal operator return Optional<Entry<Character, Long>>
				.map(entry -> entry.getKey())
				.orElse(Character.MIN_VALUE);
				
	}

	private static char countMaxOccurence(String str) {
		// TODO Auto-generated method stub
		Map<Character,Integer> result = new HashMap<>();
		
		for(char ch1: str.toCharArray()) {
			
			result.compute(ch1, (k,v) -> (v ==null)?1:++v);
			// new compute method in maps
		}
		char resultchar=' ';
		int maxOccur = Collections.max(result.values());
		for(Entry<Character, Integer> entry:result.entrySet()) {
			if(entry.getValue() == maxOccur) {
				resultchar = entry.getKey();
			}
		}
		return resultchar;
	}

	// using map
	private static Map<Character, Integer> countDuplicateCharacters(String str) {
		
		Map<Character,Integer> result = new HashMap<>();
		
		for(char ch: str.toCharArray()) {
			
			result.compute(ch, (k,v) -> (v ==null)?1:++v);
			// new compute method in maps
		}
		
		return result;
	}
	
	// using map
	private static Map<Character, Long> countDuplicateCharacters1(String str) {
			
			Map<Character,Long> result = str.chars() 
											.mapToObj(c -> (char)c)
											.collect(Collectors.groupingBy(c->c,Collectors.counting()));
					
			return result;
	}
}

/*
*	2 solutions :	
*	1. use map 
*	2. use streams
*	
*
*	Unicode 
*	surrogate pair 
*
*/
