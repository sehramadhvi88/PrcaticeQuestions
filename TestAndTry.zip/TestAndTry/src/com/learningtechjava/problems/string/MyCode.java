package com.learningtechjava.problems.string;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class MyCode {
	public static void main (String[] args) {
		System.out.println("Hello Java");
    
    List<String> list = new ArrayList<>();
    list.add("test");
    list.add("world");
    list.add("test");
    System.out.println(list);
    //List<String> newList = (List<String>) list.stream().distinct();
    
    Stream<String> streamS = list.stream().distinct();
    
    streamS.forEach(s -> System.out.println(s));
    
   Map<String,Long> mapS = list.stream().collect(Collectors.groupingBy( c->c, Collectors.counting()));
   
   System.out.println(mapS); 
   /*  2 strings 
     * check characters are same ?
     *
     * abc , bac 
     * 
     * 1. check one by one , other string contains 
     * 2. sort string compare 
     * 
     */
    	String s1 = "abc";
    	String s2 = "bac";
    		
    System.out.println(compareStrings(s1, s2));
    		
    
	}
	
	private static boolean compareStrings(String s1, String s2) {
		
		char[] str1 = s1.toCharArray();
		char[] str2 = s2.toCharArray();
		
		Arrays.sort(str1);
		Arrays.sort(str2);
		
		String ss1 = Arrays.toString(str1);
		String ss2 = Arrays.toString(str2);

		
		System.out.println(ss1 +" "+ss2);
		
		return ss1.toString().toLowerCase().equals(ss2.toString().toLowerCase());
		
		
		
	}
}