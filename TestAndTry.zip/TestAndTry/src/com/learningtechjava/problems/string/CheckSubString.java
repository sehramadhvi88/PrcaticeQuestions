package com.learningtechjava.problems.string;

import java.util.regex.Pattern;

public class CheckSubString {

	public static void main(String[] args) {
	
		String str = "JavaExamplesJavaCodeJavaProgram";
        String strFind = "Java";
		
		
		System.out.println(countStringInString(str, strFind));
		System.out.println(countStringInString1(str, strFind));
		
	}

	private static int countStringInString1(String str, String strFind) {
		// TODO Auto-generated method stub
		
		int count = str.split(Pattern.quote(strFind), -1).length - 1;
		return count;
		
		/**
		 * The split method accepts regular expression. While using the above approach, 
		 * beware of the regular expression metacharacters 
		 * (characters which have special meaning in regular expression).
		 * 
		 * In order to avoid such errors, always use the quote method of Pattern class
		 *  whenever you want to do a literal search using split method 
		 */
	}

	private static int countStringInString(String str, String strFind) {
		// TODO Auto-generated method stub
		int position = 0;
		int count = 0 ;
		int n = strFind.length();
		
		while((position = str.indexOf(strFind, position)) !=-1) {
			position += n;
			count++;
		}
		
		return count;
	}
	
}
