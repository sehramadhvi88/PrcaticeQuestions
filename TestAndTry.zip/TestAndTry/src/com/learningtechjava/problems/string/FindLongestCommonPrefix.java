package com.learningtechjava.problems.string;

public class FindLongestCommonPrefix {

	public static void main(String[] args) {
		
		String[] texts = {"abc", "abcd", "abcde", "ab", "abcd", "abcdef"};
		String[] strs = {"leets", "leetcode", "leet", "leeds"};

		System.out.println(longestCommonPrefix(texts));
	}

	private static String longestCommonPrefix(String[] texts) {
		// TODO Auto-generated method stub
		
		if(texts.length == 0) {
			return "";
		}
		
		String prefix = texts[0];
		for(int i=1;i<texts.length;i++) {
			while(texts[i].indexOf(prefix) !=0) {
				prefix = prefix.substring(0, prefix.length() - 1);
	            if (prefix.isEmpty()) return "";
			}
		}
		
		return prefix;
		
	}
}

/**
 * 	abc
	abcd
	abcde
	ab
	abcd
	abcdef
	
	from above ab is common
	
	
	Input: strs = ["flower","flow","flight"]
	Output: "fl"
	
	Input: strs = ["dog","racecar","car"]
	Output: ""
	Explanation: There is no common prefix among the input strings.
 * 
 * 
 */
