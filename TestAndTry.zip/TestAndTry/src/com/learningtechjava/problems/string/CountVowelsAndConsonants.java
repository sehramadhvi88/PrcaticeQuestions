package com.learningtechjava.problems.string;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;


public class CountVowelsAndConsonants {

	private static Set<Character> allVowels = new HashSet(Arrays.asList('a','e','i','o','u'));
	
	public static void main(String[] args) {
		
		String str = "hello";
		
		countVowelsAndConsonants(str);
		countVowelsAndConsonant2(str);
		countVowelsAndConsonant3(str);

	}

	private static void countVowelsAndConsonant3(String str) {
		// TODO Auto-generated method stub
		str = str.toLowerCase();
		
		Map<Boolean,Long> result= str.chars().mapToObj(c -> (char)c)
							//.filter(ch -> (ch >='a' && ch <='z'))
							.collect(Collectors.partitioningBy(c -> allVowels.contains(c), Collectors.counting()));
		
		System.out.println(result);
		System.out.println(result.get(true));
		System.out.println(result.get(false));
		
		/*
		 * method is a predefined method of java.util.stream.Collectors class which is used to partition
		 *  a stream of objects(or a set of elements) based on a given predicate
		 */

	}

	private static void countVowelsAndConsonant2(String str) {
		// TODO Auto-generated method stub
		str = str.toLowerCase();
		
		long vowels = str.chars().filter(c -> allVowels.contains((char)c)).count(); // chars  return intStream
		long consonants = str.chars().filter(c -> !allVowels.contains((char)c))
						.filter(ch -> (ch>='a' && ch <='z')).count();
		
		System.out.println("Vowels="+vowels);
		System.out.println("consonants="+consonants);
		
	}

	private static void countVowelsAndConsonants(String str) {
		// TODO Auto-generated method stub
		
		str = str.toLowerCase();
		int vowels = 0;
		int consonants = 0;
				
		for (int i = 0; i < str.length(); i++) {
		    char ch = str.charAt(i);
		    if (allVowels.contains(ch)) {
		      vowels++;
		    } else if ((ch >= 'a' && ch <= 'z')) {
		      consonants++;
		    }
		  }
		
		System.out.println("Vowels="+vowels);
		System.out.println("consonants="+consonants);

	}
	
	
	
}
