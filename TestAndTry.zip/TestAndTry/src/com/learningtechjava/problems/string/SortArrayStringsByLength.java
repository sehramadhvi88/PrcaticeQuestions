package com.learningtechjava.problems.string;

import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Stream;

public class SortArrayStringsByLength {

	public static void main(String[] args) {
		
		String[] strArray = {"one", "two", "three", "four", "five",
		        "six", "seven", "eight", "nine", "ten"};
		
		sortArrayByLength(strArray, Sort.ASC);
		System.out.println("===");
		sortArrayByLength1(strArray, Sort.DESC);
		System.out.println("===");
		System.out.println(sortArrayByLength2(strArray, Sort.DESC));
		
	}
	
	private static String[] sortArrayByLength2(String[] strArray, Sort direction) {
		// TODO Auto-generated method stub
		if(direction.equals(Sort.ASC)) {
			return Arrays.stream(strArray).
					sorted(Comparator.comparingInt(String::length))
					.toArray(String[]::new);
		}else {
			return Arrays.stream(strArray).
					sorted(Comparator.comparingInt(String::length).reversed())
					.toArray(String[]::new);
		}
	}

	private static void sortArrayByLength1(String[] strArray, Sort direction) {
		// TODO Auto-generated method stub
		if(direction.equals(Sort.ASC)) {
			Arrays.sort(strArray, Comparator.comparingInt(String::length));
		}else {
			Arrays.sort(strArray, Comparator.comparingInt(String::length).reversed());
		}
		Stream.of(strArray).forEach(System.out::println);
	}

	private static void sortArrayByLength(String[] strArray, Sort direction) {
		// TODO Auto-generated method stub
		if(direction.equals(Sort.ASC)) {
			Arrays.sort(strArray, (String s1, String s2) -> Integer.compare(s1.length(), s2.length()));
		}else {
			Arrays.sort(strArray, (String s1, String s2) -> (-1)*Integer.compare(s1.length(), s2.length()));
		}
		Stream.of(strArray).forEach(System.out::println);
	}

	public enum Sort{
		
		ASC,
		DESC
	}

	
}
