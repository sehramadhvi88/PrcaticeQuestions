package com.learningtechjava.problems.string;

public class CheckStringOnlyContainsDigit {

	public static void main(String[] args) {
		
		String str="1111223a";
		
		System.out.println(containsOnlyDigits(str));
		System.out.println(containsOnlyDigits2(str));
		System.out.println(containsOnlyDigits3(str));
		
	}

	private static boolean containsOnlyDigits3(String str) {
		// TODO Auto-generated method stub
		return str.matches("[0-9]+");
	}

	private static boolean containsOnlyDigits2(String str) {
		// TODO Auto-generated method stub
		return !str.chars().anyMatch(c -> !Character.isDigit(c));
		// chars return intStream from string 
	}

	private static boolean containsOnlyDigits(String str) {
		// TODO Auto-generated method stub
		
		for(int i=0;i<str.length();i++) {
			if(!Character.isDigit(str.charAt(i))) {
				return false;
			}
		}
		
		return true;
	}
	
	/*
	 *  don't use parseInt or parseeLong , its bad practice to catch NumberFormatException 
	 */
	
}
