package com.learningtechjava.problems.string;

import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ReverseLettersAndWords {
	
	private static Pattern PATTERN = Pattern.compile("/s");

	public static void main(String[] args) {
		
		String str="heello world";
		
		System.out.println(reverseWords(str));
		System.out.println(reverseWord2(str));

	}

	private static String reverseWord2(String str) {
		// TODO Auto-generated method stub
		
		return PATTERN.splitAsStream(str).
				map(w -> new StringBuilder(w).reverse())
				.collect(Collectors.joining(" "));
	}

	private static String reverseWords(String str) {
		// TODO Auto-generated method stub
		String[] words = str.split(" ");
		StringBuilder reversedString = new StringBuilder();

		for(String word:words) {
			StringBuilder reverseWord = new StringBuilder();
			
			for(int i=word.length()-1;i>=0;i--) {
				reverseWord.append(word.charAt(i));
			}
			
			reversedString.append(reverseWord).append(" ");
		}
			return reversedString.toString();
	}
	
}

/*
* 1. reverse words in a string without reversing actual word
* 2. reverse words in a string
* 3. reverse letters in a word
* 4. 
*
*/