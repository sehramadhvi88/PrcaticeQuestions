package com.learningtechjava.algods.problems;

import java.util.HashMap;

class Main {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
        
        
        HashMap<String,Integer> anagramCount= new HashMap<String,Integer>();
        
        String str1 = "KeeP";
        String str2 = "PeeK";
        
        char[] arr1 = str1.toCharArray();
        
        for(int i=0;i<arr1.length;i++) {
        	String test = String.valueOf(arr1[i]);
        	if(anagramCount.get(test) == null) {
        		anagramCount.put(test, 1);
        	}else {
        		anagramCount.put(test, anagramCount.get(test)+1);
        	}
        }
        
        char[] arr2 = str2.toCharArray();
        
        for(int i=0;i<arr2.length;i++) {
        	String test = String.valueOf(arr2[i]);
        	if(anagramCount.get(test) == null) {
        		//anagramCount.put(test, 1);
        	}else {
        		anagramCount.put(test, anagramCount.get(test)-1);
        	}
        }
        
        

        System.out.println(anagramCount); 
        
        isAnagram("keep","peeK");
    }
    
    static boolean isAnagram(String a, String b) {
        // Complete the function
        if(a == null || b == null || a.equals("") || b.equals("")){
           return false;
        }

        if(a.length() != b.length()){
            return false;
        }

         int c[] = new int[26], d[] = new int[26] ;
            a = a.toUpperCase();
            b = b.toUpperCase();
        for(int i=0; i<a.length(); i++){
             c[a.charAt(i) - 'A']++; // keep
            d[b.charAt(i) - 'A']++;  // peek 

        }
        
        
        boolean flag=true;
        for(int i =0;i<26; i++)
            {
                if(c[i] != d[i] ) 
                    {flag=false;
                    break;}
            }
        return flag;
    }


}