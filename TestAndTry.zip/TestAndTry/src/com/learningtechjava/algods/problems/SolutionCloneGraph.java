package com.learningtechjava.algods.problems;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;


public class SolutionCloneGraph {
	
	public static void main(String[] args) {
		
		// https://leetdev.io/programming-interview-study-guide/learn-breadth-first-search-graph-traversal-with-clone-graph
		
		
		int n = 4; 
		int adjList[][] = {{2,4},{1,3},{2,4},{1,3}};
		
		Node node = new Node(1);
		Node node2 = new Node(2);
		Node node3 = new Node(3);
		Node node4 = new Node(4);

		int index = 0;
		
		for(int[] edge:adjList) {
			
			Node nextNode1 = null;
			Node nextNode2 = null;

			if(edge[0] == 1)
				nextNode1 = node;
			if(edge[0] == 2)
				nextNode1 = node2;
			if(edge[0] == 3)
				nextNode1 = node3;
			if(edge[0] == 4)
				nextNode1 = node4;
			
			if(edge[1] == 1)
				nextNode2 = node;
			if(edge[1] == 2)
				nextNode2 = node2;
			if(edge[1] == 3)
				nextNode2 = node3;
			if(edge[1] == 4)
				nextNode2 = node4;
			
			switch(index) {
			case 0:
				node.neighbors.add(nextNode1);
				node.neighbors.add(nextNode2);
				break;
			case 1:
				node2.neighbors.add(nextNode1);
				node2.neighbors.add(nextNode2);
				break;
			case 2:
				node3.neighbors.add(nextNode1);
				node3.neighbors.add(nextNode2);
				break;
			case 3:
				node4.neighbors.add(nextNode1);
				node4.neighbors.add(nextNode2);
				break;
			default:
				// do nothing
			}
			index++;
		}
		
		
		Node cloneNode = cloneGraphBFS(node);
		System.out.println(cloneNode);
		
	}
	
	public static Node cloneGraphBFS(Node node) {
        
		if(node == null) {
			return null;
		}
		
		Map<Node, Node> map = new HashMap<>();
        Queue<Node> queue = new ArrayDeque<>();
        
        map.put(node, new Node(node.val)); // creating map with actual node and clone 
        queue.add(node);
        
        /*
         *  q = > 1 ,2 ,4 ,3
         */
        
        while(!queue.isEmpty()) {
        	
        	Node curNode = queue.remove();
        	
        	for(Node nextNode: curNode.neighbors) {
        		
        		if(!map.containsKey(nextNode)) {
        			map.put(nextNode, new Node(nextNode.val));
        			queue.add(nextNode);
        		}
        		
        		map.get(curNode).neighbors.add(map.get(nextNode));
        		
        	}
        	
        }
        
		
		return map.get(node);
    }
	
	public static Node cloneGraphdFS(Node node) {
        
		return null;
    }
	
}

class Node {
    public int val;
    public List<Node> neighbors;
    public Node() {
        val = 1;
        neighbors = new ArrayList<Node>();
    }
    public Node(int _val) {
        val = _val;
        neighbors = new ArrayList<Node>();
    }
    public Node(int _val, ArrayList<Node> _neighbors) {
        val = _val;
        neighbors = _neighbors;
    }
}