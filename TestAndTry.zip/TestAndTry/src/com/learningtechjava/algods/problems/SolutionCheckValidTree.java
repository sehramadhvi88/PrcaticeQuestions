package com.learningtechjava.algods.problems;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SolutionCheckValidTree {
    
	public static boolean validTree(int n, int[][] edges) {
		
        List<Set<Integer>> adjList = new ArrayList<>();
        
        // n is number of nodes
        for (int i = 0; i < n; i++) {
            adjList.add(new HashSet<>());
        }
        
        for (int[] edge : edges) {
            adjList.get(edge[0]).add(edge[1]);
            adjList.get(edge[1]).add(edge[0]);
        }
        
        
        
        boolean[] visited = new boolean[n];
        
        // Check if graph has cycle
        if (hasCycle(0, visited, adjList, -1)) {
            return false;
        }
        
        // Check if graph is connected
        for (int i = 0; i < n; i++) {
            if (!visited[i]) {
                return false;
            }
        }
        
        return true;
    }
 
    private static boolean hasCycle(int node, boolean[] visited, List<Set<Integer>> adjList, int parent) {
    	
    	visited[node] = true;
    	
    	for (int nextNode : adjList.get(node)) {
    		// (1) If nextNode is visited  but it is not the parent of the curNode, then there is cycle
            // (2) If nextNode is not visited but we still find the cycle later on, return true;
            if ((visited[nextNode] && parent != nextNode) || (!visited[nextNode] && hasCycle(nextNode, visited, adjList, node))) {
                return true;
            }
    	}
    	
    	return false;
	}

	public static void main(String[] args) {
		
    	int n = 5;
    	
    	//int edges[][] = {{0, 1}, {0, 2}, {0, 3}, {1, 4}};
    	/**
         *  0 -> 1 ,2, 3
         *  1 -> 0, 4
         *  2 -> 0
         *  3 -> 0
         *  4 -> 1
         *  
         *  	0
         *  	|
         *  /	|	\	
         *  1	2	3
         *  |
         *  4
         */
    	
    	int edges[][] = {{0, 1}, {1, 2}, {2, 3}, {1, 3}, {1, 4}};
    	
    	/**
         *  0 -> 1
         *  1 -> 0, 2, 3, 4
         *  2 -> 1, 3
         *  3 -> 1, 2
         *  4 -> 1
         *  
         *  	0
         *  	|
         *  	1	
         *  /	|	\
         *  2 -	3	4
         */
    	boolean isValid = validTree(n,edges);
    	System.out.println(isValid);
    	
	}
}
