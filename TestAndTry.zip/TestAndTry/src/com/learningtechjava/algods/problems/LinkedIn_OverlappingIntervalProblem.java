package com.learningtechjava.algods.problems;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class LinkedIn_OverlappingIntervalProblem implements  Intervals {

	List<Interval> intervalsList = new ArrayList<>();
	
	
	@Override
	public void addInterval(int from, int to) {
		// TODO Auto-generated method stub
		Interval interval = new Interval(from,to);
		intervalsList.add(interval);
	}

	@Override
	public int getTotalCoveredLength() {
		// TODO Auto-generated method stub
		
		int length=0;
		
		if(intervalsList.isEmpty()) {
			return 0;
		}
		
		// sort list
		Comparator<Interval> comp = (o1,o2) -> (o1.getStart() - o2.getStart());
		
		Collections.sort(intervalsList, comp); 
		
		System.out.println(intervalsList);
		
		Interval prev = intervalsList.get(0);
		
		for(int i=1;i<intervalsList.size();i++) {
			Interval curr = intervalsList.get(i);
			
			if(testOverLap(prev, curr)) {
                prev.start = prev.start;
				prev.setEnd(Math.max(prev.getEnd(), curr.getEnd())); 
			}else {
				length+=prev.getEnd()-prev.getStart();
				prev=curr;
			}
		}
		
		length+=prev.getEnd()-prev.getStart();
		
		return length;
	}
	
	boolean testOverLap(Interval prev,Interval current) {
		return prev.getEnd()>=current.getStart();
	}

	public static void main(String[] args) {
		
		LinkedIn_OverlappingIntervalProblem obj = new LinkedIn_OverlappingIntervalProblem();
		
		/*obj.addInterval(3, 6);
		obj.addInterval(8, 9);
		obj.addInterval(1, 5);*/
		
		obj.addInterval(5, 10);
		obj.addInterval(1, 12);
		obj.addInterval(2, 8);
		obj.addInterval(8, 16);
         
        int len = obj.getTotalCoveredLength();
         
		System.out.println("total length covered="+len);
	}  
	
}

class Interval{
	
	int start;
	int end;
	
	public Interval(int start,int end) {
		this.start=start;
		this.end=end;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getEnd() {
		return end;
	}

	public void setEnd(int end) {
		this.end = end;
	}

	@Override
	public String toString() {
		return "Interval [start=" + start + ", end=" + end + "]";
	}
	
	
	
}

interface Intervals{

	/*
	 * add an interval into internal data structure
	 */
	void addInterval(int from ,int to);
	int getTotalCoveredLength();
	
}


/**
 * Returns a total length covered by intervals.
 * If several intervals intersect, intersection should be counted only once.
 * Example:
 *
 * addInterval(3, 6)
 * addInterval(8, 9)
 * addInterval(1, 5)
 *
 * getTotalCoveredLength() -> 6
 * i.e. [1,5] and [3,6] intersect and give a total covered interval [1,6]
 * [1,6] and [8,9] don't intersect so total covered length 
 * is a sum for both intervals, that is 6. { for first interval 6-1 = 5 , for second interval 9-8 = 1 , 5+1 = 6 }
 *
 *              _______________
 *                                     ______
 *     ____________________
 *
 * 0  1    2    3    4    5   6   7    8    9    10
 *
 *	
 *
 *  [5, 10], [1, 12], [2, 8], [8, 16]
 *
 *										___________________________________________
 *          _____________________________
 *		_______________________________________________________	
 *							_______________________
 *  0  1    2    3    4    5   6   7    8    9    10    11   12   13    14   15   16

 *	solutions :
 *	1. use list to store intervals 
 *	2. sort the interval , find longest overlapping intervals & calculate length
 *
 *
 *
 */