package com.learningtechjava.algods;


public class Node {
	
	int data;
	Node next,prev;
	Node left,right;
	
	public Node(int data) {
		// TODO Auto-generated constructor stub
		this.data = data;
		left = right = next = prev = null;	
	}
}
