package com.learningtechjava.algods;

import java.util.Arrays;

public class BubbleSort {

		public static void main(String[] args) {
			
			int[] arr_to_sort= {-2, 45, 0, 11, -9};
			
			Arrays.stream(arr_to_sort).forEach(a-> System.out.print(a+" "));
			
			bubble_sort(arr_to_sort);
			
		}
	
		public static void bubble_sort(int[] arr) {
			
			for(int i=0;i<arr.length-1;i++) {
				for(int j=0;j<arr.length-i-1;j++) {
					
					if(arr[j]>arr[j+1]) {
						int temp = arr[j+1];
						arr[j+1]=arr[j];
						arr[j]=temp;
					}
				}
			}
			System.out.println("\n Sorted items");
			Arrays.stream(arr).forEach(a-> System.out.print(a+" "));
			
		}
	
}

/* 
 * [-2, 45, 0, 11, -9]
 * 
 *  step 0 : 
 *  
 *  [-2, 45, 0, 11, -9]
 *   
 *   	1) -2 > 45 ? no : yes , if yes then swap 
 *   	2) 45 > 0 ? no : yes , if yes then swap  [-2, 0, 45, 11, -9]
 *   	3) 45 > 11 ? no : yes , if yes then swap [-2, 0, 11, 45, -9]
 *   	4) 45 > -9 ? no : yes , if yes then swap [-2, 0, 11, -9, 45]
 *   
 *   step 1:
 *   
 *   [-2, 0, 11, -9, 45]
 *   
 *   	1) -2 > 0 ? no : yes , if yes then swap 
 *   	2) 0 > 11 ? no : yes , if yes then swap
 *   	3) 11 > -9 ? no : yes , if yes then swap [-2, 0, -9, 11, 45]
 *   
 *   step 2:
 *   
 *   [-2, 0, -9, 11, 45]
 *   
 *   	1) -2 > 0 ? no : yes , if yes then swap 
 *   	2) 0 > -9 ? no : yes , if yes then swap [-2, -9, 0, 11, 45]
 * 
 * ``step 3:
 *   
 *   [-2, -9, 0, 11, 45]
 *   
 *   	1) -2 > -9 ? no : yes , if yes then swap [-9, -2, 0, 11, 45]
 *   	
 * 
 * to sort the array we will pick each element one by one let say x and 
 * compare it by visit all other elements in the array until length-1-step and if this x is smaller then we will do swap
 * 
 * means we need to iterate over first n-1 , n-2 , n-3 ,......,1 elements = n(n-1)/2 => n^2
 * 
 * O(n^2)
 * 
 * Arrays.stream to iterate over int array ( IntStream)
 */
