//package com.learningtechjava.algods;
//
//import java.util.HashSet;
//import java.util.LinkedList;
//import java.util.List;
//
//
//class Solution {
//	
//	LinkedList1 skillMap= new LinkedList1();
//	boolean[] set = null;
//	
//    public int solution(int[] T, int[] A) {
//        // write your code in Java SE 8
//    	set = new boolean[T.length];
//    	for(int i=0;i<T.length;i++) {
//    		if(!set[i]){
//    			skillMap.insert(T[i], i);
//    			set[i] = true;
//    		}
//    	}
//    	
//    	return 0;
//    }
//}
//
//class LinkedList1 {
//	Node1 head;
//	
//	public void insert(int data,int index) {
//		
//		if(head == null) {
//			head = new Node1(data);
//		}else {
//			if(head.next == null) {
//				head.next = new LinkedList<Integer>();
//				Node1 node = new Node1(data);
//				Node1 ptr = head;
//			}
//			
//			while(ptr.next != null) {
//				ptr = ptr.next;
//			}
//			ptr.next=node;
//			
//		}
//	}
//}
//
//class Node1 {
//	
//	int data;
//	List<Integer> next;
//	
//	public Node1(int data) {
//		// TODO Auto-generated constructor stub
//		this.data = data;
//		next = null;	
//	}
//}
