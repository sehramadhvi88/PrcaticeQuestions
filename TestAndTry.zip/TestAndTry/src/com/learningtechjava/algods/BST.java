package com.learningtechjava.algods;


public class BST {

	// insertion into bst tree
	public static Node insert(Node root,int key) {
		
		if(root == null) {
			 return new Node(key);
		}
		
		
		if(key < root.data) {
			root.left=insert(root.left,key);
		}else {
			root.right = insert(root.right,key);
		}
		
		return root;
	}
	
	public static void inorderTraversal(Node root) {
		
		if(root == null)
			return;
		
		inorderTraversal(root.left);
		System.out.println(root.data + " ");
		inorderTraversal(root.right);

		
	}
	
	public static void search(Node root,int key,Node parent) {
		
		if(root == null) {
			return;
		}
		
		if(root.data == key) {
			
			if(parent == null)
			{
				System.out.println("the node with key "+key+" is root node");
			}
			else if(key < parent.data) {
				System.out.println("Given key is left node of node with key "+ parent.data);
			}else {
				System.out.println("Given key is right node of node with key "+ parent.data);
			}
		}
		
		if(key < root.data) {
			search(root.left,key,root);
		}else {
			search(root.right,key,root);
		}
		
		
	}
	
	public static void main(String[] args) {
		
		Node root = null;
		int[] keys = {15,10,20,8,12,16,25};
		
		for(int key:keys) {
			root = insert(root,key);
		}
		
		inorderTraversal(root);
		
		search(root,16,null);
	}
}


/*  
 *  BST is a binary search tree , having one node with one , two or zero child nodes 
 *  root node , can have two childs -> left and Right and one data value
 *  
 *  left node data value should be less than the parent node 
 *  right node data value should be greater than the parent node
 * 
 *            15
 *            /\
 * 			 /  \
 *          10  20
 *         /\    /\
 *        /  \  /  \
 *       8   12 18  25
 * 
 * 
 */
 