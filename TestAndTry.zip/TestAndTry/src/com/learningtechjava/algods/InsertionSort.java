package com.learningtechjava.algods;

import java.util.Arrays;

public class InsertionSort {

	public static void main(String[] args) {
		
		int[] arr_to_sort= {-2, 45, 0, 11, -9};
		
		Arrays.stream(arr_to_sort).forEach(a-> System.out.print(a+" "));
		
		insertion_sort(arr_to_sort);
		
	}

	public static void insertion_sort(int[] arr) {
		// TODO Auto-generated method stub
		
		int key,j;
		
		for(int i=1;i<arr.length;i++) {
			key = arr[i];
			
			j=i-1;
			
			while(j>=0 && key < arr[j]) {
				arr[j+1]=arr[j];
				j--;
			}
			
			arr[j+1]=key;
			
		}
		
		System.out.println("\n Insertion items");
		Arrays.stream(arr).forEach(a-> System.out.print(a+" "));
		
	}
	
}

/* 
 * so in insertion sort we are sorting elements like we sort cards in our hand
 * we assume , first element is always sorted, and pick each element in the array one by one as 'key' and 
 * compare that key with elements on the left if, found smaller then we will place that element at key's position
 * 
 *  average case O(n^2) 
 *  best case O(n)
 * 
 * 	-2 45 0 11 -9
 * 	[0 	1 2  3  4]	
 * 	step 0:
 *  key = 45 i=1 , j= i-1 => 0 
 *  
 *  	1. is key < a[j] , no   -2 45 0 11 -9
 *  
 *  step 1:
 *  key = 0 i=2 , j= i-1 => 1,0
 *  
 *  	1. is key < a[j] ( here j=1) ( 0 < 45)  ? no :yes , if yes a[j+1]=a[j] => -2 45 45 11 -9
 *  	2. is key < a[j] ( here j=0) ( 0 < -2)  ? no :yes , no 
 *  
 *  	a[j+1] ( j is 0 )  = key ( key is 0) => -2 0 45 11 -9
 * 
 * 	step 2:
 *  key = 11 i=3 , j= i-1 => 2,1,0
 *  
 *  	1. is key < a[j] ( here j=2) ( 11 < 45)  ? no :yes , if yes a[j+1]=a[j] => -2 0 45 45 -9
 *  	2. is key < a[j] ( here j=1) ( 11 < 0)  ? no :yes , no 
 *  
 *  	a[j+1] ( j is 1 )  = key ( key is 11) => -2 0 11 45 -9
 *  
 *  step 3:
 *  key = -9 i=4 , j= i-1 => 3,2,1,0
 *  
 *  	1. is key < a[j] ( here j=3) ( -9 < 45)  ? no :yes , if yes a[j+1]=a[j] => -2 0 11 45 45
 *  	2. is key < a[j] ( here j=2) ( -9 < 11)  ? no :yes , if yes a[j+1]=a[j] => -2 0 11 11 45 
 *      3. is key < a[j] ( here j=1) ( -9 < 0)  ? no :yes , if yes a[j+1]=a[j] => -2 0 0 11 45 
 *      4. is key < a[j] ( here j=0) ( -9 < -2)  ? no :yes , if yes a[j+1]=a[j] => -2 -2 0 11 45 
 *  
 *  	a[j+1] ( j is -1 )  = key ( key is -9) => -9 -2 0 11 45
 *  
 *  
 *  
 *  
 *  
 */


