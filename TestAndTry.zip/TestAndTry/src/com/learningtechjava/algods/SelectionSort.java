package com.learningtechjava.algods;

import java.util.Arrays;


public class SelectionSort {

	public static void main(String[] args) {
	
		int[] arr_to_sort= {-2, 45, 0, 11, -9};
		
		Arrays.stream(arr_to_sort).forEach(a-> System.out.print(a+" "));
		
		selection_sort(arr_to_sort);
			
	}

	private static void selection_sort(int[] arr_to_sort) {
		// TODO Auto-generated method stub
		
		int min_idx=0;
		
		for(int i=0;i<arr_to_sort.length-1;i++) {
			min_idx = i;
			
			for(int j=i+1;j<arr_to_sort.length;j++) {
				
				if(arr_to_sort[min_idx] > arr_to_sort[j]) {
					min_idx=j;
				}
			}
			int temp = arr_to_sort[i];
			arr_to_sort[i] = arr_to_sort[min_idx];
			arr_to_sort[min_idx] = temp;
		}
		System.out.println("\n");
		Arrays.stream(arr_to_sort).forEach(a-> System.out.print(a+" "));
		
	}
	
}

/*
 * With selection sort we are selecting the mininum index element and comparing it with rest of
 * elements , if we found another minimum index element we then compare with the index element
 * . once all elements we will swap. 
 * one by one and placing it at the begining of array
 * 
 * a= [ -2 45 0 11 -9 ] 
 *    	 0  1 2  3  4
 * step 0:
 * 
 * min_idx = 0 
 * 
 * 	j = 1 , if a[min_idx] > a[j] ? min_idx = j 
 * 	j = 2 , if a[min_idx] > a[j] ? min_idx = j 
 * 	j = 3 , if a[min_idx] > a[j] ? min_idx = j
 *  j = 4 , if a[min_idx] > a[j] ? min_idx = j , true = > min_idx = 4
 *  
 *  swap min_idx and i values 
 *  a= [ -9 45 0 11 -2 ] 
 *  	  0  1 2  3  4
 *  
 *  step 1:
 *  
 *  min_idx = 1 
 * 
 * 	j = 2 , if a[min_idx] > a[j] ? min_idx = j , true => min_idx = 2
 * 	j = 3 , if a[min_idx] > a[j] ? min_idx = j
 *  j = 4 , if a[min_idx] > a[j] ? min_idx = j , true = > min_idx = 4
 *  
 *  swap min_idx and i values 
 *  a= [ -9 -2 0 11 45 ] 
 *  	  0  1 2  3  4
 *  
 *  step 2:
 *  
 *  min_idx = 2 
 * 
 * 	j = 3 , if a[min_idx] > a[j] ? min_idx = j
 *  j = 4 , if a[min_idx] > a[j] ? min_idx = j 
 *  
 * 
 * Complexity = O(n^2)
 * 
 * Number of comparisons:(n-1) + (n-2) + (n-3) +.....+ 1 = n(n-1)/2 nearly equals to n2
 * 
 * 
 * 
 */

