package com.learningtechjava.array;

import java.util.ArrayList;
import java.util.List;

public class BetterProgrammerTask2 {

    public static List<Integer> getPrimeNumbers(int from, int to) {
        /*
          Please implement this method to
          return a list of all prime numbers in the given range (inclusively).
          A prime number is a natural number that has exactly two distinct natural number divisors, which are 1 and the prime number itself.
          The first prime numbers are: 2, 3, 5, 7, 11, 13
         */
    		int flag ;
    		ArrayList<Integer> primeNum = new ArrayList<Integer>();
    		for(int i=from;i<=to;i++) {
    			
    			if(i==1 || i==0) {
    				continue;
    			}
    			
    			flag = 1;
    			
    			for(int j=2;j<=i/2;j++) {
    				if(i%j==0)
    					{
    						flag = 0;
    						break;
    					}
    					
    			}
    			
    			if(flag ==1) {
    				primeNum.add(i);
    			}
    			
    		}
    	return primeNum;
    }
    
    public static void main(String[] args) {
		
    	System.out.println(getPrimeNumbers(2,11)); 
    	
	}
}
