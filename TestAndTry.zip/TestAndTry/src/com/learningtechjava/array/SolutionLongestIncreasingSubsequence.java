package com.learningtechjava.array;

class SolutionLongestIncreasingSubsequence {
    
	public static int lengthOfLIS(int[] nums) {
        
		if(nums.length == 0) {
			return 0;
		}
		
		int dp[] = new int[nums.length];
		
		dp[0] = 1;
		int maxans = 1;
		
		for(int i=1; i<dp.length; i++) {
			int maxval = 0;
			for(int j=0; j<i; j++) {
				if(nums[i] > nums[j]) {
					maxval = Math.max(maxval, dp[j]);
				}
			}
			dp[i] = maxval+1;
			maxans = Math.max(maxans, dp[i]);
		}
		
		/*
		 *  10 9 2 5 3 7 101    -> input  
		 *  0  1 2 3 4 5  6  
		 * 
		 * 	1  1 1 2 2 3  4			-> dp
		 * 
		 * Time complexity : O(n^2). Two loops of n are there
		 * Space complexity : O(n) dp array of size nn is used.
		 */
		
		return maxans;
    }
	
	public static void main(String[] args) {
		
		int nums[] = {3, 10, 2, 1, 20}; //{10,9,2,5,3,7,101,18};
		
		System.out.println(lengthOfLIS(nums));
		
		int nums1[] = {50, 3, 10, 7, 40, 80}; //{0,1,0,3,2,3};
		
		System.out.println(lengthOfLIS(nums1));
		
		int nums2[] = {7,7,7,7,7,7,7};
		
		System.out.println(lengthOfLIS(nums2));

		int nums3[] = {2, 6, 3, 4, 1, 2, 9, 5, 8}; //{10, 22, 9, 33, 21, 50, 41, 60, 80} ;
		
		System.out.println(lengthOfLIS(nums3));

		
		
	}
}