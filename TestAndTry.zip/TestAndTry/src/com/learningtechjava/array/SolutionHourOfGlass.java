package com.learningtechjava.array;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class SolutionHourOfGlass {



    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int[][] arr = new int[6][6];
        List<Integer> list = new ArrayList<Integer>();
        for (int i = 0; i < 6; i++) {
            String[] arrRowItems = scanner.nextLine().split(" ");
            scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

            for (int j = 0; j < 6; j++) {
                int arrItem = Integer.parseInt(arrRowItems[j]);
                arr[i][j] = arrItem;
            }
        }

        System.out.println("Solution 1");
        // solution 1
        for(int row=0;row<4;row++){
            for(int col=0;col<4;col++){
                    int sum=getHourGlass(row,col,arr);
                    list.add(sum);
            }
        }

        if(!list.isEmpty()) {
        Collections.sort(list);
        System.out.println(list.get(list.size()-1));
        }else {
        	System.out.println(0);
        }
        
        System.out.println("Solution 2");
        // solution 2 
        int result = hourglassSum(arr);
        System.out.println(result); 

        scanner.close();
    }

    static int getHourGlass(int i,int j,int[][] arr){

            int sum=0;
           // System.out.println(arr[0][0]);
            int a,b;
            for(a=i;a<=i+2;a=a+2){
                for(b=j;b<=j+2;b=b+1){
                    sum = arr[a][b]+ sum;
                }
                if(a <=i)
                {   
                    int k=a,l=b;
                    sum = arr[k+1][l-2]+sum;
                    }
            }

        return sum;
    }
    
    static int hourglassSum(int[][] arr) {
        
        int maxSum=0;
        int row = 6;
        int col = 6;
        for(int a=0;a< row-2;a++){
            for(int b=0;b< col-2;b++){
                int sum = (arr[a][b]+arr[a][b+1]+arr[a][b+2])
                        + arr[a+1][b+1]
                        +(arr[a+2][b]+arr[a+2][b+1]+arr[a+2][b+2]);
                maxSum = Math.max(maxSum, sum);
            }
            
        }

    return maxSum;
}

}
