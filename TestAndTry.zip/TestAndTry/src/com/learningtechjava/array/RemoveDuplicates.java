package com.learningtechjava.array;

public class RemoveDuplicates {
	
	public static void main(String[] args) {
		
	}
	
	static int removeDuplicates(int a[]) {
		
		return 0;
	}

}
