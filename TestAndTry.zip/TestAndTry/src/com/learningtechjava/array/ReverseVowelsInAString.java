package com.learningtechjava.array;

// Class name must be "Main"
// Libraries included:
// json simple, guava, apache commons lang3, junit, jmock
/**
Reverse Vowels of String: 
Example: CODING -> CIDONG, READING -> RIADENG(EAI -> IAE -> RIADENG)
**/
/** MADHVI'S COMMENT:
1. iterate over the string , at each position which one is vowel , collection that in an array 
2. re-iterate over string , start from end ( vowel array ) where ever I encounter vowel replace it 
    
[ e ,a , i] 
    
    r e a d i n g ( o(n)) 
    r i  a d e n g ( o(n/2) ) 
    
    O(n) + O(n/2) 
    
**/

import java.util.ArrayList;
import java.util.stream.Stream;

class ReverseVowelsInAString {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
        
        String str = "READING";
        ArrayList<Character> vowels= new ArrayList<Character>(); 
        
        for(int i=0;i<str.length();i++)
        {
        	if(str.charAt(i) == 'A' || str.charAt(i) == 'E' || str.charAt(i) == 'I' || 
        			str.charAt(i) == 'O' ||str.charAt(i) == 'U') {
        		vowels.add(str.charAt(i));  
        	}
        }
         
        System.out.println(vowels);
        
        int len = vowels.size();
        
        int counter = len-1;
        
        char arr[] = str.toCharArray();
        
        for(int i=0;i<arr.length;i++) {
        	
        	if(arr[i] == 'A' || arr[i] == 'E' || arr[i] == 'I' || 
        			arr[i] == 'O' ||arr[i] == 'U') {
        		
                // not using replace , because it replace all occurrences of that character 
        		arr[i]=vowels.get(counter);
        		counter--;
        	}
        }
        
        System.out.println(String.valueOf(arr)); 
    }
}
    


 
        
    
    
    
    