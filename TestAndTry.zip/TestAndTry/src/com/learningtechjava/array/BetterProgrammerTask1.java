package com.learningtechjava.array;

public class BetterProgrammerTask1 {

    public static int getClosestToZero(int[] a) {
        /*
          Please implement this method to
          return the number in the array that is closest to zero.
          If there are two equally close to zero elements like 2 and -2
          - consider the positive element to be "closer" to zero.
         */
    	int target=0;
    	int n = a.length;
    	
    	if(a[0]>=target) {
    		return a[0];
    	}
    	if(target>=a[n-1])
    	{
    		return a[n-1];
    	}
    	
    	int i=0, j= n, mid = 0;
    	
    	while(i<j) {
    		
    		mid = (i+j)/2;
    		
    		if(a[mid]==target) {
    			return a[mid];
    		}
    		
    		if(a[mid]<target) {
    			if(mid > 0 && target>a[mid-1]) {
    				if(target-a[mid] >= a[mid-1]-target) {
    					return a[mid-1];
    				}else {
    					return a[mid];
    				}
    			}
    			j=mid;
    		}else {
    			if(mid < n-1 && target < a[mid-1]) {
    				if(target-a[mid] >= a[mid+1]-target) {
    					return a[mid+1];
    				}else {
    					return a[mid];
    				}
    			}
    			i= mid+1;
    		}
    		
    	}
    	
    	return a[mid];
    }
    
    public static void main(String[] args) {
		
    	int arr[] = {1,2,3,-1,-2};
    	//int target=0;
    	System.out.println(getClosestToZero(arr));
    	
	}
}