package com.learningtechjava.array;

import java.util.Arrays;
import java.util.BitSet;

public class FindMissingNumber {
	
	public static void main(String[] args) {
		
		
		int[] iArray = new int[]{1, 2, 3, 5}; 
		int missing = getOneMissingNumber(iArray, 5);
		System.out.println("Missing number in array:="+missing);

		
		getMissingNumber(new int[]{1, 2, 3, 4, 6}, 6);
		
		// one missing number
		getMissingNumber(new int[]{1, 2, 3, 4, 6, 7, 9, 8, 10}, 10);
		
		// three missing number 
		getMissingNumber(new int[]{1, 2, 3, 4, 6, 9, 8}, 10);


	}
	
	// if number are from 1 to n and only one number is missing
	static int getOneMissingNumber(int[] a,int count) {
		
		int expectedSum = (count*(count+1))/2;
		
		int actualSum = Arrays.stream(a).sum();
		
		return expectedSum-actualSum;
	}
	
	// if one or more than one is missing using BitSet 
	static int getMissingNumber(int a[],int count) {
		int missingCount = count - a.length;
		BitSet bitset = new BitSet(count);
		
		System.out.println("now bitset="+bitset);
		
		for(int i:a) {
			bitset.set(i-1);
		}
		
		System.out.println("now bitset="+bitset);

		int lastMissingIndex=0;
		for(int i=0;i<missingCount;i++) {
			lastMissingIndex = bitset.nextClearBit(lastMissingIndex); // return index of bit that is set to false , on or after specified index
			System.out.println(++lastMissingIndex);
		}
		
		double testDouble = 50.0f / 100;
		
		System.out.println("testDouble="+testDouble); 
		return 0;
	}
	
	
	
	
	

}

/*	
 *  	1) find missing number on an array integer of 1 to 100 
 *  
 *  	solu: if number are from 1 - 100 then we can use formula : n(n+1)/2 ( sum of n integers )
 *  
 *   	2) find duplicates in array / or more than one missing number 
 *   	
 *   	solu : use BitSet  - > available in java.util , creates an array of bits represented by boolean values 
 *   	
 * 
 */
