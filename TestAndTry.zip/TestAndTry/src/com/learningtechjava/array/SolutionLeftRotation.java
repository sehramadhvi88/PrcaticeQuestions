package com.learningtechjava.array;
import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class SolutionLeftRotation {

    // Complete the rotLeft function below.
    static int[] rotLeft(int[] a, int d) {

		while( d > 0){
            int i = 0;
            int temp = a[i];
            while(i <= a.length-2){
                a[i] = a[i+1];
                i = i +1;;
            }
            a[i] = temp;
            d--;
        }
        
        return a;
    }
    
    static void leftRotate(int arr[], int n, int k)
    {
        /* To get the starting point of
        rotated array */
        int mod = k % n; // [ 4 % 5 returns 4 , can't divide by 5 ] 
 
        // Prints the rotated array from
        // start position
        for (int i = 0; i < n; ++i)
            System.out.print(arr[(i + mod) % n] + " ");
 
        System.out.println();
    }

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
        //BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        String[] nd = scanner.nextLine().split(" ");

        int n = Integer.parseInt(nd[0]);

        int d = Integer.parseInt(nd[1]);

        int[] a = new int[n];
        int[] b = new int[n];


        String[] aItems = scanner.nextLine().split(" ");
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

        for (int i = 0; i < n; i++) {
            int aItem = Integer.parseInt(aItems[i]);
            a[i] = aItem;
            b[i] = aItem;

        }

        int[] result = rotLeft(a, d);

        for (int i = 0; i < result.length; i++) {
            //bufferedWriter.write(String.valueOf(result[i]));
        	System.out.println(result[i]); 
//            if (i != result.length - 1) {
//                //bufferedWriter.write(" ");
//            }
        }
        
        leftRotate(b, n, 7);

        //bufferedWriter.newLine();

        //bufferedWriter.close();

        scanner.close();
    }
}
