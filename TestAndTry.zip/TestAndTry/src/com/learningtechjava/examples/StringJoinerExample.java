package com.learningtechjava.examples;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;

public class StringJoinerExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> list = Arrays.asList("java", "python", "nodejs", "ruby");

		//java | python | nodejs | ruby
		String result = list.stream().map(x -> "RecordTypeId =" + x ).collect(Collectors.joining(" OR "));
		
		System.out.println(result);
		
		System.out.println(testMethod(1));
		
		System.out.println(testMethod1(5)); 
		
		String str = "xyz";
		System.out.println("sub str"+str.substring(0, 0));  
		
		String str1 = "abc";
		char[] ch = str1.toCharArray();
		String str2 = String.valueOf(ch);
		System.out.println(str2);
		
		
		ArrayList<Integer> list1 = new ArrayList<>(10);
		
		System.out.println(list1.size());
	}
	
	 static boolean testMethod(int a) {
		
		 boolean flag=false;
		 
		 try {
			 
			 if(a==0) {
			int i=100/a;
			 }else {
				 flag = true;
			 }
			 
			 return flag;
		 }catch(Exception e) {
			 flag = false;
			 //return (6 > 0?false:true);
			 return flag;
		 }
	}
	 
	 static boolean testMethod1(int a) {
		 
		 Object obj = new Object();
		 
		 return (obj!=null);
	 }

}


