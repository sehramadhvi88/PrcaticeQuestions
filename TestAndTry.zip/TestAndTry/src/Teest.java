import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class Teest {
	
	public static void main(String[] args) {
	
		String str = "Bad programmers worry about the code. Good programmers worry about data structures and their relationships.";
		String[] arr = {"about", "the"};
		
		System.out.println(mostOccuringWord(str,arr));
	}

	private static String mostOccuringWord(String str, String[] arr){
		
		String[] strArr = str.replace(".", "").split("\\s");
		
//		HashMap<String,Integer> wordCount = new HashMap<String,Integer>();
//		
//		for(String s:strArr) {
//			
//			if(!Arrays.asList(arr).contains(s)) {
//			 wordCount.compute(s, (k,v) -> v == null ? 1: ++v);
//			}
//		}
//		
//		System.out.println(wordCount);
		// find key with max value
		
		String key = Arrays.stream(strArr).filter(s -> !Arrays.asList(arr).contains(s))
				.collect(Collectors.groupingBy(c-> c,Collectors.counting())).entrySet()
				.stream().max(Map.Entry.comparingByValue()).get().getKey();
		
		return key;
		
	}
	
}


/**
*
* Bad programmers worry about the code. 
* Good programmers worry about data structures and their relationships
* 
* "about", "the"
*
*/