import java.util.LinkedHashMap;
import java.util.Map;

public class TestGap {

	public static void main(String[] args) {
		
		String str = "gapbcgap";
		
		System.out.println(findNonRepeatedCharacter(str));
		
	}

	private static String findNonRepeatedCharacter(String str) {
		// TODO Auto-generated method stub
		
		Map<String,Integer> charMap = new LinkedHashMap<String,Integer>();
		
		for(char c : str.toCharArray()) {
			
			charMap.compute(String.valueOf(c), (k,v) -> v == null ? 1:++v); // default to 1 else increment
			
		}
		
		System.out.println(charMap);
		
		for(Map.Entry<String,Integer> entrySet:charMap.entrySet()) {
			if(entrySet.getValue() == 1) {
				return entrySet.getKey();
			}
		}
		 return "no non repeated character";
		
	}
	
}


/** 
 *  find first non - repeated character 
 *  gapbcgap , val 1 
 *  
 *  
 *  
 */
